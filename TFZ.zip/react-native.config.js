module.exports = {
    project: {
    android: {}
    },
    assets: ['./app/assets/fonts'],
 };