export const font = {
    black: 'Montserrat-Black',
    bold: 'Montserrat-Bold',
    regular: 'Montserrat-Regular'
}