import React from 'react';
import { View, Text, ScrollView, StyleSheet, Dimensions, Image, TouchableOpacity, Modal, ActivityIndicator, Alert } from 'react-native'
import EllipticalButton from '../components/functionalComponent/EllipticalButton';
import Entypo from 'react-native-vector-icons/dist/Entypo';
import { tfz_black_logo, workout_1, start_workout } from '../consts/images';
import { font } from '../consts/fontFamily';
import { NavigationEvents } from 'react-navigation';
const { height, width } = Dimensions.get('screen');
import YoutubePlayer from "react-native-youtube-iframe";
import { useSelector,useDispatch } from 'react-redux';
import { AlternateExercise } from '../model/workout';
import {alternateExercises, getAlternateExerciseById, submitWorkout} from '../reducers/workout/service-calls';
import { checkDayDiff } from '../lib/dateLib';

export const DuringWorkoutOne = (props) => {

    const [timer, setTimer] = React.useState(1);
    const [pause, setPause] = React.useState(true);
    const [videoPlay,playVideo] = React.useState(true);
    const [videoLink,setLink] = React.useState('4XcGTvcSRxY')
    const [exercise,setExercise] = React.useState('');
    const [initialLoad,setInitialLoad] = React.useState(true);
    const [index,setIndex] = React.useState(-1);
    const [rep,setRep] = React.useState(1);
    const [playlistData,setPlaylistData] = React.useState([]);
    const [loopValue,setLoop] = React.useState(false);
    const _youtubeRef = React.useRef();
    const {picked_alternate,isAlternateSet,workout_day} = useSelector(state => state.WorkoutReducer);
    const {authResponse} = useSelector(state => state.AuthReducer);
    const dispatch = useDispatch();
    const {item} = props.navigation.state.params;
    const [day_of_workout,setDayOfWorkout] = React.useState('1');

    React.useEffect(()=>{
        fetchApi();
        console.log('workout_day: ',workout_day);
        if(workout_day !== null){
            setDayOfWorkout(checkDayDiff(workout_day));
        }else{
            setDayOfWorkout('1');
        }
        AlternateExercise.user_id= authResponse.user_id;
        AlternateExercise.exercise_id = exercise.exercise_id;
        AlternateExercise.user_id = authResponse.user_id;
        AlternateExercise.workout_frequency_id = authResponse.workout_frequency_id;
        AlternateExercise.goal_id = authResponse.goal_id;
        AlternateExercise.workout_plan_id = authResponse.workout_plan_id;
        AlternateExercise.workout_type_id = authResponse.workout_type_id;
        AlternateExercise.workout_day = day_of_workout;
    },[])

    const fetchApi = () => {
        setPause(true);
        playVideo(false);
        console.log('item length: ',item.length,index)
        console.log('Exercise id: ',exercise.exercise_id);
        if(index<4){
            console.log('Initiated: ',((item[index+1].youtube).split('=')[1]).split('&')[0]);
            setExercise(item[index+1]);//exercise object
            setIndex(index+1);//exercise index(from 5)
            getLoopPlaylist( ((item[index+1].youtube).split('=')[1]).split('&')[0], item[index+1].reps );
            setInitialLoad(false);
            setPause(false);
            playVideo(true);
        }else{
            console.log('Submit called');
            let submitData = {
                user_id: authResponse.user_id,//"199",
                workout_frequency_id: authResponse.workout_frequency_id,
                goal_id: authResponse.goal_id,
                workout_plan_id: authResponse.workout_plan_id,
                workout_type_id: authResponse.workout_type_id,
                workout_day: day_of_workout,//"1",
                workout_details_by_user_id: "1"
            }
            submitWorkout(submitData).then(res=>{
                console.log('Success submit: ',res);
                props.navigation.navigate('PostWorkout')
            }).catch(ex=>{
                console.log('Failure submit: ',ex);
            })
        }
    }

    React.useEffect(() => {
        if (!pause) {
            setTimeout(() => {
                setTimer(timer + 1)
            }, 1000);
        }else if(pause){
            setTimer(timer)
        }
    }, [timer])

    const fetchAlternate = ()=>{
        setInitialLoad(true);
        playVideo(false);
        AlternateExercise.exercise_id = exercise.exercise_id;
        dispatch({type: 'ALTERNATE_PICKED',isAlternateSet: false,picked_alternate:[]})
        setPause(true)
        console.log('alt called: ',AlternateExercise)
        alternateExercises(AlternateExercise).then(res=>{
            setInitialLoad(false);
            console.log('Success alternate: ',res.data);
            dispatch({type: 'SET_ALTERNATE_EXERCISE',alternate_exercise: res.data.alternate_exercise});
            props.navigation.toggleDrawer();
        }).catch(ex=>{
            setInitialLoad(false);
            console.log('Failed',ex);
        })
    }
    
    React.useEffect(()=>{
        console.log('isAlternateSet check: ',isAlternateSet)
        if(isAlternateSet){
            console.log('called: ',((picked_alternate.youtube).split('=')[1]).split('&')[0])
            setExercise(picked_alternate);//exercise object
            setIndex(index);//exercise index(from 5) - replace with already selected index
            getLoopPlaylist( ((picked_alternate.youtube).split('=')[1]).split('&')[0], picked_alternate.reps );
            setLoop(true);
            playVideo(true);
            props.navigation.toggleDrawer();
        }
    },[isAlternateSet])

    const alternateById = () => {
        let data = {
            "user_id": "90",
            "workout_frequency_id": "14",
            "goal_id": "13",
            "workout_plan_id": "23",
            "workout_type_id": "11",
            "workout_day": "1",
            "exercise_id": "9",
            "alternate_exercise_id": "26"
        }    
        getAlternateExerciseById(data).then(res=>{
            console.log('Success: ',res.data);
        }).catch(ex=>{
            console.log('Failure');
        })
    }

    const getLoopPlaylist = (videoId,reps) => {
        if(videoId !== ''){
            let value = [...Array(reps)].map((_,i)=>videoId);
            console.log('playlist: ',value);
            setPlaylistData(value)
        }else{
            setPlaylistData(['4XcGTvcSRxY'])
        }   
    }

    const getVideoDuration = () => {
        console
        .log('duration called')
        if(!initialLoad){
        _youtubeRef.current.getDuration().then(res=>{
            console.log('time: ',res);
            return (res.toString());
            return '1';
        }).catch(ex=>{
            return '0';
        })
    }
    }

    return (
        <View style={[StyleSheet.absoluteFill, { flex: 1, paddingHorizontal: width * 0.04 }]}>
            {/* <NavigationEvents
                onDidFocus={() => [setPause(false), setTimer(timer + 1)]}
            /> */}
            <Modal
                transparent={true}
                visible={initialLoad}
                onRequestClose={()=>{setInitialLoad(false)}}>
                <View style={{flex:1, justifyContent:'center',alignItems:'center',backgroundColor:'rgba(0,0,0,0.5)'}}>
                    <ActivityIndicator size='large' color='blue' />
                </View>
            </Modal>
            <ScrollView showsVerticalScrollIndicator={false}>
                <View style={{ marginTop: height * 0.04, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                    <EllipticalButton
                        ellipticClick={() => fetchAlternate()}
                        width={width * 0.4}
                        height={height * 0.07}
                        btnImg={''}
                        btnSize={width * 0.05}
                        btnText={'Alternate'}
                        bgColor='#4069ff'
                        labelColor='white'
                        fontWeight='bold'
                    />
                    <TouchableOpacity onPress={() => props.navigation.pop()} style={{
                        backgroundColor: 'red', width: width * 0.1, height: width * 0.1, alignItems: 'center', justifyContent: 'center',
                        borderRadius: (width * 0.1) / 2
                    }}>
                        <Entypo name='cross' size={width * 0.05} color='white' />
                    </TouchableOpacity>
                </View>
                <View style={{ margin: height * 0.1, alignItems: 'center' }}>
                    <Text style={{ color: 'black', fontSize: height * 0.035, fontFamily: font.bold, marginBottom: height * 0.02 }}>
                        "{exercise.exercise_name}"
                    </Text>
                    <YoutubePlayer
                        ref={_youtubeRef}
                        height={height * 0.3}
                        width={350}
                        play={videoPlay}
                        onReady={() => [playVideo(true)]}
                        videoId={exercise !== ''? ((exercise.youtube).split('=')[1]).split('&')[0] : '4XcGTvcSRxY'}
                        playList={playlistData}
                        onChangeState={(e) => {
                            if(e === 'ended'){
                                console.log('rep condition: ',rep,exercise.reps)//not handled for alternate
                                setRep(rep+1);
                                setPause(true);
                                setTimer(0)
                                playVideo(true);
                                if (isAlternateSet) {
                                    if (rep < (picked_alternate.reps)+1) {
                                        setLoop(true);
                                    } else {
                                        setTimer(1)
                                        fetchApi();
                                        setRep(1);
                                        setLoop(false);
                                        console.log('reps over')
                                        dispatch({type: 'ALTERNATE_PICKED',isAlternateSet: false,picked_alternate:[]})
                                    }
                                } else {
                                    if (rep < (exercise.reps)+1) {
                                        console.log('looping: ',playlistData)
                                        setLoop(true);
                                    } else {
                                        setTimer(1)
                                        fetchApi();
                                        setRep(1);
                                        setLoop(false);
                                        console.log('reps over')
                                    }
                                }
                                
                            } else if(e === 'playing') {
                                console.log('playing')
                                setPause(false);
                                setTimer(timer+1)
                            } else if(e === 'paused'){
                                setPause(true);
                            }
                        }
                        }
                        initialPlayerParams={{ loop: loopValue, rel: false, controls: true, modestbranding: false }}
                    />
                    <Text style={{ color: 'black', fontSize: height * 0.03, fontFamily: font.bold, marginVertical: height * 0.06 }}>
                        "Sets: {exercise.sets} & reps: {exercise.reps}"
                    </Text>
                    <Text style={{ color: 'black', fontSize: height * 0.045, fontFamily: font.bold, marginVertical: height * 0.02 }}>
                        {/* {timer} */}
                        {getVideoDuration()}
                    </Text>
                    <EllipticalButton
                        ellipticClick={() => {
                            playVideo(!videoPlay)
                            if(videoPlay){
                                props.navigation.navigate('DuringWorkoutTwo',{exe_name: exercise.exercise_name,exe_img: exercise.workout_image})
                            }else{
                                console.log('Play video')
                            }
                          }}
                        width={width * 0.8}
                        height={height * 0.07}
                        btnImg={''}
                        btnSize={width * 0.05}
                        btnText={'PAUSE'}
                        bgColor='#e08b02'
                        labelColor='white'
                        fontWeight='bold'
                    />
                    <View style={{ marginVertical: height * 0.02 }}>
                        <EllipticalButton
                            ellipticClick={() => props.navigation.navigate('DuringWorkoutTwo')}
                            width={width * 0.8}
                            height={height * 0.07}
                            btnImg={''}
                            btnSize={width * 0.05}
                            btnText={'SKIP'}
                            bgColor='#e08b02'
                            labelColor='white'
                            fontWeight='bold'
                        />
                    </View>
                </View>
            </ScrollView>
        </View>
    );
}

export const DuringWorkoutTwo = (props) => {
    const [timer, setTimer] = React.useState(0);
    const [pause, setPause] = React.useState(false);
    React.useEffect(() => {
        if (!pause) {
            setTimeout(() => {
                setTimer(timer + 1)
            }, 1000);
        }
    }, [timer])
    return (
        <View style={[StyleSheet.absoluteFill, { flex: 1, backgroundColor: 'white', paddingHorizontal: width * 0.04 }]}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <View style={{ marginTop: height * 0.04, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end' }}>
                    <View style={{
                        backgroundColor: 'red', width: width * 0.1, height: width * 0.1, alignItems: 'center', justifyContent: 'center',
                        borderRadius: (width * 0.1) / 2
                    }}>
                        <Entypo name='cross' size={width * 0.05} color='white' />
                    </View>
                </View>
                <View style={{ alignItems: 'center' }}>
                    <Text style={{ color: 'black', fontSize: height * 0.09, fontFamily: font.regular, marginVertical: height * 0.2 }}>
                        REST
                    </Text>
                    <Text style={{ color: 'black', fontSize: height * 0.055, fontFamily: font.bold, marginVertical: height * 0.02 }}>
                        {timer}
                    </Text>
                    <EllipticalButton
                        ellipticClick={() => { setPause(!pause); setTimer(timer + 1) }}
                        width={width * 0.8}
                        height={height * 0.07}
                        btnImg={''}
                        btnSize={width * 0.05}
                        btnText={'PAUSE'}
                        bgColor='#e08b02'
                        labelColor='white'
                        fontWeight='bold'
                    />
                    <View style={{ marginVertical: height * 0.02 }}>
                        <EllipticalButton
                            ellipticClick={() => props.navigation.pop()}
                            width={width * 0.8}
                            height={height * 0.07}
                            btnImg={''}
                            btnSize={width * 0.05}
                            btnText={'SKIP'}
                            bgColor='#e08b02'
                            labelColor='white'
                            fontWeight='bold'
                        />
                    </View>
                </View>
            </ScrollView>
        </View>
    );
}
