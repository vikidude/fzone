export let NextWorkout = {
    user_id: "",
    workout_frequency_id: "",
    goal_id: "",
    workout_plan_id: "",
    workout_type_id: "",
    existing_workout_day: ""
}

export let AlternateExercise = {
    user_id: "",
    workout_frequency_id: "",
    goal_id: "",
    workout_plan_id: "",
    workout_type_id: "",
    workout_day: "",
    exercise_id: ""
}